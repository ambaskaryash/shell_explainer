# shell_explainer
Commands related to Windows, Linux and Mac explained using MAN command on UI
